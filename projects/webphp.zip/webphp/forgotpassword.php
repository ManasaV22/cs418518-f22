<?php include 'controllers/authController.php' ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" />
  <link rel="stylesheet" href="main.css">
  <title>User verification system PHP - Login</title>
  
<style type="text/css">
    body{
      background-color:#F8F8FF
    }
</style>
</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-md-4 offset-md-4 form-wrapper auth login">
        <h3 class="text-center form-title">Forgot Password</h3>
                                 
        <form action="login.php" method="post">

        <div class="form-group">
          <label>Email</label>
          <input type="text" name="username" class="form-control form-control-lg">
          <div class="form-group"><br>
            <button type="submit" name="submit-btn" class="btn btn-lg btn-block">Submit</button>
          </div>
        </div>
        <p>Verify your email to reset your password</p>
        <p>Want to Login? <a href="login.php"> Click here</a></p>
  </div>
</body>
</html>